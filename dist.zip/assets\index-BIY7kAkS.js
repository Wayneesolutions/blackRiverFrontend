import{j as e}from"./index-Dax8QRoc.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
