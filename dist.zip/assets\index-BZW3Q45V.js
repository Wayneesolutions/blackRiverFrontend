import{j as e}from"./index-DNlewkUi.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
