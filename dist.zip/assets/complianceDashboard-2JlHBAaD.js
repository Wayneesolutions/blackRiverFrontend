import{D as a}from"./index-BKIaK375.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
