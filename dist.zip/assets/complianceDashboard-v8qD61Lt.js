import{D as a}from"./index-D_gcyUHl.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
