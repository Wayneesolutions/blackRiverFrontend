import{D as a}from"./index-DLdzZy_K.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
