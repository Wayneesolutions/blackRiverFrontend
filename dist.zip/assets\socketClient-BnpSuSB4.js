import{l as o}from"./vendor-socket-BcxXcwBL.js";let t=null;const n=()=>(t||(t=o("https://portal.logistiqinnovations.ca",{autoConnect:!0})),t);export{n as g};
