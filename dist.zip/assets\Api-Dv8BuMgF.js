import{j as r}from"./index-BdS1xsia.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
