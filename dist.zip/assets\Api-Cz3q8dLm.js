import{j as r}from"./index-BlQVFKvL.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
