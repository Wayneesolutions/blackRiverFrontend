import{j as e}from"./index-Ckh0-b2d.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
