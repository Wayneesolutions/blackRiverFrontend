import{j as e}from"./index-BlQVFKvL.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
