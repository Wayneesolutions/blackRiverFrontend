import{l as o}from"./index-TjCxX7sJ.js";let t=null;const l=()=>(t||(t=o("http://localhost:3000",{autoConnect:!0})),t);export{l as g};
