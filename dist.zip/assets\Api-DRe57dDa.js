import{j as r}from"./index-Dax8QRoc.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
