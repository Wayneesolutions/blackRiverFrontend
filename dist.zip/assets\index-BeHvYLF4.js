import{j as e}from"./index-C92tmXyE.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
