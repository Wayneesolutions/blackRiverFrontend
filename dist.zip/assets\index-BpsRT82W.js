import{j as e}from"./index-jPlsr5kg.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
