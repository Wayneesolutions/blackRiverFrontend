import{j as d}from"./index-jPlsr5kg.js";function o(){return d.jsx("div",{children:"HosAndEld"})}export{o as default};
