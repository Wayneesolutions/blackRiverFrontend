import{d as i,ay as r}from"./index-sHDxRXE4.js";/**
 * @license lucide-react v0.541.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["rect",{width:"7",height:"7",x:"3",y:"3",rx:"1",key:"1g98yp"}],["rect",{width:"7",height:"7",x:"14",y:"3",rx:"1",key:"6d4xhi"}],["rect",{width:"7",height:"7",x:"14",y:"14",rx:"1",key:"nxv5o0"}],["rect",{width:"7",height:"7",x:"3",y:"14",rx:"1",key:"1bb6yr"}]],d=i("layout-grid",s),h=async t=>(await r.get("admin/fleet-maintenance/mechanic/orders",{params:t})).data,p=async t=>(await r.get("admin/fleet-maintenance/mechanic/dashboard",{params:t})).data,m=async(t,e,n)=>{const a=new FormData;return a.append("repairDetails",e.repairDetails),a.append("totalAmount",String(e.totalAmount)),e.parts&&e.parts.length>0&&a.append("parts",JSON.stringify(e.parts)),a.append("invoice",n),(await r.post(`admin/fleet-maintenance/general-repairs/${t}/complete`,a)).data};export{d as L,m as c,p as g,h as l};
