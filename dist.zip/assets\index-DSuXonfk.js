import{j as e}from"./index-CeCLQpyp.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
