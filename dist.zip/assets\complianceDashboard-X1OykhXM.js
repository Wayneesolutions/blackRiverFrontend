import{C as a}from"./index-C5W2EUYc.js";const o=async()=>(await a.get("/admin/compliance/dashboard")).data;export{o as f};
