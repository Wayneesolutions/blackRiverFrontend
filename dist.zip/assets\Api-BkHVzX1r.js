import{j as r}from"./index-WkRvDwc3.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
