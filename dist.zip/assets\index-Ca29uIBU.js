import{j as e}from"./index-DlIKzyUt.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
