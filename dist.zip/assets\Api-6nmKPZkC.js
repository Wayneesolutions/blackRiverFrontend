import{j as r}from"./index-Ckh0-b2d.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
