import{j as r}from"./index-BMSRrnNe.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
