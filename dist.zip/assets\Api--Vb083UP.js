import{j as r}from"./index-C92tmXyE.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
