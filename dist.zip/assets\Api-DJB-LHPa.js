import{j as r}from"./index-DlIKzyUt.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
