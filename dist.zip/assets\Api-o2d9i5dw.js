import{j as r}from"./index-CeCLQpyp.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
