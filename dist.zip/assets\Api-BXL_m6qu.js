import{j as r}from"./index-n8UGP4V3.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
