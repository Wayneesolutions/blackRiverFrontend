import{j as d}from"./index-DOUyh6Dv.js";function o(){return d.jsx("div",{children:"HosAndEld"})}export{o as default};
