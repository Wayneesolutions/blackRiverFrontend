import{dj as o}from"./index-WkRvDwc3.js";let t=null;const l=()=>(t||(t=o("http://localhost:3000",{autoConnect:!0})),t);export{l as g};
