import{j as r}from"./index-sHDxRXE4.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
