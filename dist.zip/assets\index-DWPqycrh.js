import{j as e}from"./index-WkRvDwc3.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
