import{ds as o}from"./index-sHDxRXE4.js";let t=null;const l=()=>(t||(t=o("http://localhost:3000",{autoConnect:!0})),t);export{l as g};
