import{j as e}from"./index-DLH0ffys.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
