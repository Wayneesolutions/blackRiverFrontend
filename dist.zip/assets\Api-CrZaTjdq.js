import{j as r}from"./index-jPlsr5kg.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
