import{j as d}from"./index-DNlewkUi.js";function o(){return d.jsx("div",{children:"HosAndEld"})}export{o as default};
