import{j as e}from"./index-DOUyh6Dv.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
