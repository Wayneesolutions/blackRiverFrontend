import{dp as o}from"./index-BMSRrnNe.js";let t=null;const l=()=>(t||(t=o("http://localhost:3000",{autoConnect:!0})),t);export{l as g};
