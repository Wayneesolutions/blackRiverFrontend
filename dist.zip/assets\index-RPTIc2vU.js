import{j as e}from"./index-DvGOr6w8.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
