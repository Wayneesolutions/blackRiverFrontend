import{j as r}from"./index-B87sO_rx.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
