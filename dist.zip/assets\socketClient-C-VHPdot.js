import{dq as o}from"./index-DLH0ffys.js";let t=null;const l=()=>(t||(t=o("http://localhost:3000",{autoConnect:!0})),t);export{l as g};
