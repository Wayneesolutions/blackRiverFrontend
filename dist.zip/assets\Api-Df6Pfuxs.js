import{j as r}from"./index-DOUyh6Dv.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
