import{dr as o}from"./index-B87sO_rx.js";let t=null;const r=()=>(t||(t=o("http://localhost:3000",{autoConnect:!0})),t);export{r as g};
