import{j as e}from"./index-BdS1xsia.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
