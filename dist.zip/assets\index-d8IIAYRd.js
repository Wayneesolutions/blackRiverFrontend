import{j as e}from"./index-BMSRrnNe.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
