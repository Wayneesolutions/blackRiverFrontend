import{j as e}from"./index-BLzCfNQF.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
