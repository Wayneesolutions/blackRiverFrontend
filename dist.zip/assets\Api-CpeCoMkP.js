import{j as r}from"./index-DNlewkUi.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
