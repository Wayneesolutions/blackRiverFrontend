import{j as e}from"./index-n8UGP4V3.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
