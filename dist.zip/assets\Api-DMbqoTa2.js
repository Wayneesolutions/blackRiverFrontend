import{j as r}from"./index-DvGOr6w8.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
