import{j as r}from"./index-DLH0ffys.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
