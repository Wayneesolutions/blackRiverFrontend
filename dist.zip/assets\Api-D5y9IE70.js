import{j as r}from"./index-BLzCfNQF.js";const i=()=>r.jsx("div",{children:"Api"});export{i as default};
