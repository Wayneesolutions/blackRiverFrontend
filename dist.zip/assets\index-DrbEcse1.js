import{j as e}from"./index-B87sO_rx.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
