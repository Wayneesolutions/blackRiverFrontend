import{j as e}from"./index-sHDxRXE4.js";const t=()=>e.jsx("div",{children:"index"});export{t as default};
